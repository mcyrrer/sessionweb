<?php

$data = array();
$data['page'] = 1;
$data['total'] = 500;
$data['rows'][] = array('id' => "1",'cell' => array( "1", "Not Executed", "My Session","Mattias Gustavsson","MAR12","MyPages","2012-01-01 12:12", "keypad,siren"));
$data['rows'][] = array('id' => "2",'cell' => array( "2", "Closed", "My Session","Mattias Gustavsson","MAR12","MyPages","2012-01-01 12:12", "keypad,siren"));
$data['rows'][] = array('id' => "3",'cell' => array( "3", "In progress", "My Session","Mattias Gustavsson","MAR12","MyPages","2012-01-01 12:12", "keypad,siren"));
$data['rows'][] = array('id' => "4",'cell' => array( "4", "Executed", "My Session","Mattias Gustavsson","MAR12","MyPages","2012-01-01 12:12", "keypad,siren"));
$data['rows'][] = array('id' => "5",'cell' => array( "5", "Debriefed", "My Session","Mattias Gustavsson","MAR12","MyPages","2012-01-01 12:12", "keypad,siren"));
$data['rows'][] = array('id' => "7",'cell' => array( "Incoming", "TestA", "TestB"));
$data['rows'][] = array('id' => "7",'cell' => array( "Incoming", "TestA", "TestB"));
$data['rows'][] = array('id' => "8",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "9",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "10",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "11",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "12",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "13",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "14",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "15",'cell' => array( "Outgoing", "TestA", "TestB"));
$data['rows'][] = array('id' => "16",'cell' => array( "Other", "TestA", "TestB"));
$data['rows'][] = array('id' => "17",'cell' => array( "Other", "TestA", "TestB"));
$data['rows'][] = array('id' => "18",'cell' => array( "Other", "TestA", "TestB"));
$data['rows'][] = array('id' => "19",'cell' => array( "Other", "TestA", "TestB"));
$data['rows'][] = array('id' => "20",'cell' => array( "Other", "TestA", "TestB"));
$data['rows'][] = array('id' => "21",'cell' => array( "Other", "TestA", "TestB"));


echo json_encode($data);

?>